# Ez SHOT SE (CI 자동 APK 빌드)

이 패키지는 **GitHub Actions**로 Windows/사내망 설정 없이도 APK를 자동으로 빌드할 수 있도록 구성되어 있습니다.

## 사용 방법 (가장 쉬운 순서)

1) GitHub에서 새 Repository 생성
2) 이 ZIP을 풀어서 **EzSHOTSE_Android 폴더 안의 모든 파일/폴더를** Repository 루트에 업로드  
   - 업로드 후 Repository 루트에 `settings.gradle.kts`, `app/` 폴더가 보여야 합니다.
3) GitHub → **Actions** 탭 → `Build EzSHOTSE Debug APK` 선택
4) **Run workflow** 클릭
5) 빌드가 끝나면 실행 결과 페이지 아래쪽 **Artifacts**에서 `EzSHOTSE-debug-apk` 다운로드
6) 압축을 풀면 `app-debug.apk`가 들어 있습니다.

## 참고
- 이 프로젝트는 UVC 라이브러리로 `com.github.jiangdongguo.AndroidUSBCamera:libausbc:3.2.10`(JitPack)을 사용합니다.
- GitHub Actions 환경에서는 JitPack/Google Maven을 정상적으로 접근할 수 있어 빌드가 통과합니다.
