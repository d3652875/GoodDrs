# Ez SHOT SE (Android) - UVC 구강카메라 뷰어 (Inskam 참고 UI)

## 포함 기능(요청 반영: '완성')
- Inskam 스타일 메뉴: Camera / Album / Settings
- UVC(OTG) 프리뷰
- 스냅샷(사진) 저장
- 영상 녹화(Start/Stop)
- 회전(0/90/180/270)
- 해상도 프리셋(480/720/1080)
- 환자명/치아번호 입력(카메라 탭 연필 아이콘)
- 저장 폴더 규칙:
  - Pictures/EzSHOTSE/<환자>/<YYYY-MM-DD>/<치아>/snapshot_...jpg
  - Movies/EzSHOTSE/<환자>/<YYYY-MM-DD>/<치아>/record_...mp4
- 외부 캡처 버튼(HID) 지원:
  - SPACE/ENTER/VOL+/CAMERA/FOCUS/HEADSETHOOK/PLAY-PAUSE
- 손떨림 방지(스냅샷):
  - 버튼 입력 순간의 흔들림을 피하기 위해 0.3~0.4초 동안 여러 프레임을 잡아
    '가장 선명한 프레임'을 자동 선택하여 저장(베스트 프레임)

## 빌드/실행
1) Android Studio에서 폴더 열기(settings.gradle.kts가 있는 루트)
2) Gradle Sync
3) OTG 지원 안드로이드 기기에서 실행
4) USB OTG로 UVC 구강카메라 연결

## 아이콘(로고)
- 현재는 기본 런처 아이콘입니다.
- anycam.net의 Ez SHOT SE 공식 로고를 받으면,
  Android Studio의 Image Asset(Launcher Icons)로 ic_launcher를 생성해 넣으면 됩니다.


## 빌드 참고(JitPack)
- UVC 라이브러리는 JitPack 저장소에서 받아옵니다. 사내망/방화벽에서 jitpack.io가 차단되면 의존성 다운로드가 실패할 수 있습니다.


## libausbc 버전
- 현재 의존성: com.github.jiangdongguo.AndroidUSBCamera:libausbc:3.2.10 (JitPack)
