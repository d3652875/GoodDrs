package com.gooddrs.ezshotse

import android.graphics.Bitmap
import android.os.Bundle
import android.view.*
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.gooddrs.ezshotse.databinding.DialogCaseBinding
import com.gooddrs.ezshotse.databinding.FragmentCameraBinding
import com.jiangdg.ausbc.base.CameraFragment
import com.jiangdg.ausbc.callback.ICaptureCallBack
import com.jiangdg.ausbc.callback.ICameraStateCallBack
import com.jiangdg.ausbc.camera.CameraRequest
import com.jiangdg.ausbc.camera.bean.PreviewSize
import com.jiangdg.ausbc.camera.CameraRequest.PreviewFormat
import com.jiangdg.ausbc.camera.CameraRequest.RenderMode
import com.jiangdg.ausbc.camera.CameraRequest.AudioSource
import com.jiangdg.ausbc.camera.bean.RotateType
import com.jiangdg.ausbc.widget.IAspectRatio
import java.io.File

/**
 * Ez SHOT SE (Inskam 참고 UI)
 * - Live Preview
 * - Photo / Video Start-Stop
 * - Rotate
 * - Resolution preset
 * - 환자/치아 저장 규칙
 * - 손떨림 방지(스냅샷): 베스트 프레임 선택
 * - 외부 버튼(HID): SPACE 등 키 입력으로 스냅샷
 */
class UvcCameraFragment : CameraFragment() {

    private var vb: FragmentCameraBinding? = null
    private var isRecording = false
    private var rotateType = RotateType.ANGLE_0

    private val baseFolder = "EzSHOTSE"

    // Presets
    private val presets = listOf(
        PreviewSize(640, 480),
        PreviewSize(1280, 720),
        PreviewSize(1920, 1080),
    )
    private var currentPresetIndex = 1

    // External triggers debounce
    private var lastShotMs = 0L

    override fun getRootView(inflater: LayoutInflater, container: ViewGroup?): View {
        if (vb == null) vb = FragmentCameraBinding.inflate(inflater, container, false)
        return vb!!.root
    }

    override fun getCameraView(): IAspectRatio? = vb?.tvCameraRender

    override fun getCameraViewContainer(): ViewGroup? = vb?.cameraContainer

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        vb?.btnPhoto?.setOnClickListener { triggerSnapshot("UI_BUTTON") }
        vb?.btnVideo?.setOnClickListener { toggleVideo() }
        vb?.btnRotate?.setOnClickListener { rotate() }
        vb?.btnResolution?.setOnClickListener { chooseResolution() }
        vb?.btnCase?.setOnClickListener { showCaseDialog() }

        refreshCaseLabel()
    }

    override fun getCameraRequest(): CameraRequest {
        val size = presets[currentPresetIndex]
        return CameraRequest.Builder()
            .setPreviewWidth(size.width)
            .setPreviewHeight(size.height)
            .setRenderMode(RenderMode.OPENGL)
            .setDefaultRotateType(rotateType)
            .setAudioSource(AudioSource.SOURCE_AUTO)
            .setPreviewFormat(PreviewFormat.FORMAT_MJPEG)
            .setAspectRatioShow(true)
            .create()
    }

    override fun onCameraState(self: com.jiangdg.ausbc.camera.ICamera, code: ICameraStateCallBack.State, msg: String?) {
        vb?.tvStatus?.text = when (code) {
            ICameraStateCallBack.State.OPENED -> "연결됨"
            ICameraStateCallBack.State.CLOSED -> "연결 해제"
            ICameraStateCallBack.State.ERROR -> "오류: ${msg ?: "unknown"}"
        }
    }

    /** 외부 HID/키 입력에서 호출됨 */
    fun onExternalSnapshotTrigger(source: String) {
        triggerSnapshot(source)
    }

    private fun triggerSnapshot(source: String) {
        val now = System.currentTimeMillis()
        if (now - lastShotMs < 400) return
        lastShotMs = now
        capturePhotoWithStabilization(source)
    }

    private fun capturePhotoWithStabilization(source: String) {
        val patient = EzPrefs.getPatient(requireContext()).ifBlank { "Unknown" }
        val teeth = EzPrefs.getTeeth(requireContext()).ifBlank { "Unknown" }
        val stabOn = EzPrefs.isStabOn(requireContext())

        val outFile = CapturePath.newSnapshotFile(requireContext(), baseFolder, patient, teeth)

        if (!stabOn) {
            // 라이브러리 기본 캡처
            captureImage(simpleCaptureCallback(isVideo = false), outFile.absolutePath)
            return
        }

        // 손떨림 방지: TextureView에서 짧은 버스트로 여러 프레임을 잡아 베스트 프레임 저장
        val tv = vb?.tvCameraRender
        if (tv == null) {
            captureImage(simpleCaptureCallback(isVideo = false), outFile.absolutePath)
            return
        }

        toast("손떨림 방지 캡처...")

        val frames = mutableListOf<Bitmap>()
        val handler = tv.handler
        // TextureView가 가진 Handler가 없을 수 있어서 View.post 사용
        val total = 8
        val intervalMs = 45L  // 약 360ms

        fun grab(i: Int) {
            try {
                val bmp = tv.bitmap
                if (bmp != null) frames.add(bmp)
            } catch (_: Throwable) {
            }
            if (i + 1 >= total) {
                finalizeStabSave(frames, outFile)
            } else {
                tv.postDelayed({ grab(i + 1) }, intervalMs)
            }
        }
        grab(0)
    }

    private fun finalizeStabSave(frames: List<Bitmap>, outFile: File) {
        try {
            if (frames.isEmpty()) {
                // fallback
                captureImage(simpleCaptureCallback(isVideo = false), outFile.absolutePath)
                return
            }
            val best = ImageStabilizer.pickSharpest(frames)
            best.compress(Bitmap.CompressFormat.JPEG, 95, outFile.outputStream())
            toast("사진 저장 완료")
        } catch (e: Exception) {
            toast("사진 저장 실패: ${e.message}")
        } finally {
            frames.forEach { if (!it.isRecycled) it.recycle() }
        }
    }

    private fun toggleVideo() {
        val patient = EzPrefs.getPatient(requireContext()).ifBlank { "Unknown" }
        val teeth = EzPrefs.getTeeth(requireContext()).ifBlank { "Unknown" }
        val out = CapturePath.newVideoFile(requireContext(), baseFolder, patient, teeth)

        if (!isRecording) {
            captureVideoStart(object : ICaptureCallBack {
                override fun onBegin() {
                    isRecording = true
                    vb?.btnVideo?.alpha = 0.6f
                    toast("녹화 시작")
                }
                override fun onError(error: String?) {
                    isRecording = false
                    vb?.btnVideo?.alpha = 1.0f
                    toast("녹화 실패: ${error ?: "unknown"}")
                }
                override fun onComplete(path: String?) {
                    isRecording = false
                    vb?.btnVideo?.alpha = 1.0f
                    toast("녹화 완료")
                }
            }, out.absolutePath, 0)
        } else {
            captureVideoStop()
        }
    }

    private fun rotate() {
        rotateType = when (rotateType) {
            RotateType.ANGLE_0 -> RotateType.ANGLE_90
            RotateType.ANGLE_90 -> RotateType.ANGLE_180
            RotateType.ANGLE_180 -> RotateType.ANGLE_270
            RotateType.ANGLE_270 -> RotateType.ANGLE_0
            else -> RotateType.ANGLE_0
        }
        setRotateType(rotateType)
    }

    private fun chooseResolution() {
        val names = presets.map { "${it.width} x ${it.height}" }.toTypedArray()
        AlertDialog.Builder(requireContext())
            .setTitle("해상도 선택")
            .setSingleChoiceItems(names, currentPresetIndex) { dlg, which ->
                currentPresetIndex = which
                val size = presets[which]
                updateResolution(size.width, size.height)
                dlg.dismiss()
                toast("해상도: ${size.width}x${size.height}")
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun showCaseDialog() {
        val b = DialogCaseBinding.inflate(layoutInflater)
        b.etPatient.setText(EzPrefs.getPatient(requireContext()))
        b.etTeeth.setText(EzPrefs.getTeeth(requireContext()))
        b.cbStab.isChecked = EzPrefs.isStabOn(requireContext())

        AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.case_title))
            .setView(b.root)
            .setPositiveButton("저장") { _, _ ->
                val patient = b.etPatient.text?.toString()?.trim().orEmpty()
                val teeth = b.etTeeth.text?.toString()?.trim().orEmpty()
                EzPrefs.set(requireContext(), patient, teeth, b.cbStab.isChecked)
                refreshCaseLabel()
                toast("저장됨")
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun refreshCaseLabel() {
        val p = EzPrefs.getPatient(requireContext()).ifBlank { "환자 미설정" }
        val t = EzPrefs.getTeeth(requireContext()).ifBlank { "치아 미설정" }
        vb?.tvCase?.text = "$p / $t"
    }

    private fun simpleCaptureCallback(isVideo: Boolean): ICaptureCallBack {
        return object : ICaptureCallBack {
            override fun onBegin() { toast(if (isVideo) "저장 중..." else "사진 저장 중...") }
            override fun onError(error: String?) { toast("저장 실패: ${error ?: "unknown"}") }
            override fun onComplete(path: String?) { toast("저장 완료") }
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        vb = null
        super.onDestroyView()
    }
}
