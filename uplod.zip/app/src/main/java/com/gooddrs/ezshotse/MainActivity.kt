package com.gooddrs.ezshotse

import android.os.Bundle
import android.view.KeyEvent
import androidx.appcompat.app.AppCompatActivity
import com.gooddrs.ezshotse.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var vb: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vb = ActivityMainBinding.inflate(layoutInflater)
        setContentView(vb.root)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, UvcCameraFragment())
                .commit()
        }

        vb.bottomNav.setOnItemSelectedListener { item ->
            val f = when (item.itemId) {
                R.id.nav_camera -> UvcCameraFragment()
                R.id.nav_album -> AlbumFragment()
                R.id.nav_settings -> SettingsFragment()
                else -> UvcCameraFragment()
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, f)
                .commit()
            true
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            val snapshotKeys = setOf(
                KeyEvent.KEYCODE_SPACE,
                KeyEvent.KEYCODE_ENTER,
                KeyEvent.KEYCODE_VOLUME_UP,
                KeyEvent.KEYCODE_CAMERA,
                KeyEvent.KEYCODE_FOCUS,
                KeyEvent.KEYCODE_HEADSETHOOK,
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            )

            if (event.keyCode in snapshotKeys) {
                val f = supportFragmentManager.findFragmentById(R.id.fragmentContainer)
                if (f is UvcCameraFragment) {
                    f.onExternalSnapshotTrigger("KEY_${event.keyCode}")
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }
}
