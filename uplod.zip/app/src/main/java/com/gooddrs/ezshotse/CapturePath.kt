package com.gooddrs.ezshotse

import android.content.Context
import android.os.Environment
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CapturePath {

    private val sdfDate = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val sdfTs = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)

    fun sanitize(name: String): String {
        val cleaned = name.trim().replace(Regex("[\\/:*?\"<>|]"), "")
        return if (cleaned.isBlank()) "Unknown" else cleaned
    }

    fun buildCaseDir(ctx: Context, baseFolder: String, patient: String, teeth: String, isVideo: Boolean): File {
        val dateFolder = sdfDate.format(Date())
        val p = sanitize(patient)
        val t = sanitize(teeth.replace(Regex("[,\s]+"), "_").replace("~", "-"))

        val root = if (isVideo) {
            File(ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES), baseFolder)
        } else {
            File(ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES), baseFolder)
        }

        val dir = File(File(File(root, p), dateFolder), t)
        dir.mkdirs()
        return dir
    }

    fun newSnapshotFile(ctx: Context, baseFolder: String, patient: String, teeth: String): File {
        val ts = sdfTs.format(Date())
        val dir = buildCaseDir(ctx, baseFolder, patient, teeth, isVideo = false)
        val tag = sanitize(teeth.replace(Regex("[,\s]+"), "-"))
        return File(dir, "snapshot_${ts}_${tag}.jpg")
    }

    fun newVideoFile(ctx: Context, baseFolder: String, patient: String, teeth: String): File {
        val ts = sdfTs.format(Date())
        val dir = buildCaseDir(ctx, baseFolder, patient, teeth, isVideo = true)
        val tag = sanitize(teeth.replace(Regex("[,\s]+"), "-"))
        return File(dir, "record_${ts}_${tag}.mp4")
    }
}
