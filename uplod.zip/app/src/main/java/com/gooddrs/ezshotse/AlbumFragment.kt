package com.gooddrs.ezshotse

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.gooddrs.ezshotse.databinding.FragmentAlbumBinding
import java.io.File

/**
 * Album 탭: 앱이 저장한 폴더를 직접 스캔해서 목록 표시 (Android 버전 차이/MediaStore 이슈 회피)
 */
class AlbumFragment : Fragment() {

    private var vb: FragmentAlbumBinding? = null
    private val adapter = MediaAdapter { item ->
        val uri = FileProvider.getUriForFile(
            requireContext(),
            "${requireContext().packageName}.fileprovider",
            item.file
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, item.mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(intent)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        vb = FragmentAlbumBinding.inflate(inflater, container, false)
        return vb!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        vb?.recycler?.layoutManager = LinearLayoutManager(requireContext())
        vb?.recycler?.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        val items = LocalAlbumScanner.scan(requireContext(), baseFolder = "EzSHOTSE")
        adapter.submit(items)
    }

    override fun onDestroyView() {
        vb = null
        super.onDestroyView()
    }
}
