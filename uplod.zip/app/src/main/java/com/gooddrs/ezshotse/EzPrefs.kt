package com.gooddrs.ezshotse

import android.content.Context

object EzPrefs {
    private const val PREF = "ezshotse_pref"
    private const val K_PATIENT = "patient"
    private const val K_TEETH = "teeth"
    private const val K_STAB = "stab"

    fun getPatient(ctx: Context): String = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        .getString(K_PATIENT, "") ?: ""

    fun getTeeth(ctx: Context): String = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        .getString(K_TEETH, "") ?: ""

    fun isStabOn(ctx: Context): Boolean = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        .getBoolean(K_STAB, true)

    fun set(ctx: Context, patient: String, teeth: String, stab: Boolean) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString(K_PATIENT, patient)
            .putString(K_TEETH, teeth)
            .putBoolean(K_STAB, stab)
            .apply()
    }
}
