package com.gooddrs.ezshotse

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.gooddrs.ezshotse.databinding.RowMediaBinding

data class AlbumItem(
    val file: java.io.File,
    val displayName: String,
    val mimeType: String,
    val dateText: String
)

class MediaAdapter(
    private val onClick: (AlbumItem) -> Unit
) : RecyclerView.Adapter<MediaAdapter.VH>() {

    private val items = mutableListOf<AlbumItem>()

    fun submit(newItems: List<AlbumItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val vb = RowMediaBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(vb)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class VH(private val vb: RowMediaBinding) : RecyclerView.ViewHolder(vb.root) {
        fun bind(item: AlbumItem) {
            vb.tvTitle.text = item.displayName
            vb.tvSub.text = "${item.dateText}  •  ${item.mimeType}"
            vb.root.setOnClickListener { onClick(item) }
        }
    }
}
