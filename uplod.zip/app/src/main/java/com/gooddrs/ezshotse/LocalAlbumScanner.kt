package com.gooddrs.ezshotse

import android.content.Context
import android.os.Environment
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object LocalAlbumScanner {

    private val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

    fun scan(ctx: Context, baseFolder: String): List<AlbumItem> {
        val out = mutableListOf<AlbumItem>()

        val picRoot = File(ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES), baseFolder)
        val movRoot = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES), baseFolder)

        listFilesRecursive(picRoot).forEach { f -> out.add(toItem(f)) }
        listFilesRecursive(movRoot).forEach { f -> out.add(toItem(f)) }

        return out.sortedByDescending { it.file.lastModified() }
    }

    private fun listFilesRecursive(root: File): List<File> {
        if (!root.exists()) return emptyList()
        val res = mutableListOf<File>()
        val stack = ArrayDeque<File>()
        stack.add(root)
        while (stack.isNotEmpty()) {
            val d = stack.removeFirst()
            d.listFiles()?.forEach { f ->
                if (f.isDirectory) stack.add(f)
                else if (f.isFile) res.add(f)
            }
        }
        return res
    }

    private fun toItem(f: File): AlbumItem {
        val name = f.name
        val mime = when {
            name.endsWith(".jpg", true) || name.endsWith(".jpeg", true) -> "image/jpeg"
            name.endsWith(".png", true) -> "image/png"
            name.endsWith(".mp4", true) -> "video/mp4"
            name.endsWith(".avi", true) -> "video/*"
            else -> "*/*"
        }
        val dt = sdf.format(Date(f.lastModified()))
        return AlbumItem(f, name, mime, dt)
    }
}
