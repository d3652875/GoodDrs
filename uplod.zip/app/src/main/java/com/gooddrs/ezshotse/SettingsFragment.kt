package com.gooddrs.ezshotse

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.gooddrs.ezshotse.databinding.FragmentSettingsBinding

class SettingsFragment : Fragment() {

    private var vb: FragmentSettingsBinding? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        vb = FragmentSettingsBinding.inflate(inflater, container, false)
        return vb!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        vb?.tvInfo?.text =
            "Ez SHOT SE\n\n" +
            "외부 캡처 버튼(HID) 단축키\n" +
            "- SPACE / ENTER\n" +
            "- VOL+ / CAMERA / FOCUS\n" +
            "- HEADSETHOOK / PLAY-PAUSE\n\n" +
            "Camera 탭의 [연필 아이콘]에서\n환자명/치아번호 및 손떨림 방지 ON/OFF 설정"
    }

    override fun onDestroyView() {
        vb = null
        super.onDestroyView()
    }
}
