package com.gooddrs.ezshotse

import android.graphics.Bitmap
import kotlin.math.abs

/**
 * 손떨림 방지(스냅샷용) - 베스트 프레임 선택
 * - 여러 프레임(Bitmap)을 받아 선명도(라플라시안 분산) 점수가 가장 높은 프레임을 선택
 * - 속도를 위해 다운스케일해서 계산
 */
object ImageStabilizer {

    data class Scored(val bmp: Bitmap, val score: Double)

    fun pickSharpest(frames: List<Bitmap>, sampleWidth: Int = 320): Bitmap {
        if (frames.isEmpty()) throw IllegalArgumentException("frames empty")
        val scored = frames.map { Scored(it, sharpnessScore(it, sampleWidth)) }
        return scored.maxBy { it.score }.bmp
    }

    private fun sharpnessScore(src: Bitmap, sampleWidth: Int): Double {
        val w = src.width
        val h = src.height
        if (w <= 0 || h <= 0) return 0.0

        val scale = sampleWidth.toFloat() / w.toFloat()
        val sw = sampleWidth
        val sh = (h * scale).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createScaledBitmap(src, sw, sh, true)

        // grayscale
        val pix = IntArray(sw * sh)
        bmp.getPixels(pix, 0, sw, 0, 0, sw, sh)
        val gray = IntArray(sw * sh)
        for (i in pix.indices) {
            val c = pix[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            gray[i] = (r * 30 + g * 59 + b * 11) / 100
        }

        // Laplacian kernel: 0 1 0 / 1 -4 1 / 0 1 0
        var sum = 0.0
        var sum2 = 0.0
        var count = 0

        fun idx(x: Int, y: Int) = y * sw + x

        for (y in 1 until sh - 1) {
            for (x in 1 until sw - 1) {
                val c = gray[idx(x, y)]
                val lap = gray[idx(x, y - 1)] + gray[idx(x - 1, y)] + gray[idx(x + 1, y)] + gray[idx(x, y + 1)] - 4 * c
                val v = lap.toDouble()
                sum += v
                sum2 += v * v
                count++
            }
        }

        if (count <= 1) return 0.0
        val mean = sum / count
        val varr = (sum2 / count) - (mean * mean)
        return abs(varr)
    }
}
